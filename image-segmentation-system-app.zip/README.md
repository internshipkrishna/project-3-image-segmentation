# Image Segmentation System

Run with `python app.py` in GitHub Codespaces.
